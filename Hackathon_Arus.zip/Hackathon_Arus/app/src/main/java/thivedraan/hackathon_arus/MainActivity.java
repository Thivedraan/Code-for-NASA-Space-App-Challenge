package thivedraan.hackathon_arus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    DatabaseReference mDatabase1 = FirebaseDatabase.getInstance().getReference("Hack");
    private TextView text1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text1  = findViewById(R.id.cond);
        valuechart1();

    }

    private void valuechart1() {
        mDatabase1.addValueEventListener(new ValueEventListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot smallSnapshot : dataSnapshot.getChildren()){
                    final int condition = smallSnapshot.child("Cond").getValue(Integer.class);
                    new Thread() {
                        public void run() {
                            try {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (condition == 1){
                                            text1.setText("S01");
                                        }
                                        else if (condition == 2){
                                            text1.setText("S02");
                                        }
                                        else if (condition == 3){
                                            text1.setText("S03");
                                        }
                                    }
                                });
                                Thread.sleep(50);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }.start();
                }
                Log.d("..","RECIEVE");
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
}
